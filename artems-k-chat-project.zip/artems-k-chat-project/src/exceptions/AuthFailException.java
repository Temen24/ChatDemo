package exceptions;

public class AuthFailException extends Exception {
}
