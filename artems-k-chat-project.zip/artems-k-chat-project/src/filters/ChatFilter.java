package filters;


public interface ChatFilter {
    String filter(String message);
}
